package de.ibykus.oasx.view.beans;

import de.ibykus.oasx.controller.basispraemie.BasispraemieRepository;
import de.ibykus.oasx.controller.basispraemie.BasispraemieRechnung;
import de.ibykus.oasx.controller.basispraemie.BasispraemieRepository.EBasisraemieTiere;
import de.ibykus.oasx.controller.basispraemie.dto.BasispraemieAggregatInfo;
import de.ibykus.oasx.controller.basispraemie.dto.BasispraemieResult;
import de.ibykus.oasx.controller.common.logger.OasLogger;
import de.ibykus.oasx.controller.common.logger.OasLoggerFactory;
import de.ibykus.oasx.cupcake.template.utils.FragTim;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

@Named("basisPraemieRechnerBean")
@ViewScoped
public class BasisPraemieRechnerBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    private BasispraemieRepository repository;

    @Inject
    private Oas21SessionBean sessionBean;
    private final OasLogger logger = OasLoggerFactory.getLogger(this.getClass());

    private BigDecimal afHa;
    private BigDecimal dglHa;
    private BigDecimal dkHa;
    private BigDecimal flaecheGesamt;
    private String betriebsname;
    private String anschrift;
    private boolean wirtschaftsform;
    private boolean junglandwirt;
    private boolean gibtKuhmilchAb;
    private Map<EBasisraemieTiere, BigDecimal> tierData = new EnumMap<>(EBasisraemieTiere.class);
    private Map<String, BigDecimal> gesData = new HashMap<>();
    @Inject
    private BasispraemieRechnung basispraemieRechnung;
    private BasispraemieResult basispraemieResult;
    private String currentYear = String.valueOf(FragTim.getCurrentYear());
    private String disclaimer = "Der Prämienrechner dient nur als Hilfestellung und erste Orientierung bei der Beantragung von Fördermaßnahmen. " +
                    "Es kann nicht ausgeschlossen werden, dass es noch zu Änderungen der Förderungsvoraussetzungen kommt. " +
                    "Daher erfolgen alle Berechnungen ohne Gewähr. \nDie zur Berechnung verwendeten Daten stammen " +
                    "aus dem Gemeinsamen Antrag. Hierzu wurden Informationen aus den Formularen \"Direktzahlung\", " +
                    "\"Gekoppelte Einkommensstützung\" und Angaben aus dem \"Flächen- und Nutzungsnachweis\" verwendet.";

    // Temporär
    private String customValue1;
    private String customValue2;
    private boolean acknowledged = false;
    private boolean checkboxAgreed = false;

    @PostConstruct
    public void init() {
        try {
            String pi = sessionBean.getOasxUser().getPI();
            BasispraemieAggregatInfo aggregatInfo = repository.loadAllForPi(pi);

            // Flächen
            this.afHa = aggregatInfo.getAfHa();
            this.dglHa = aggregatInfo.getDglHa();
            this.dkHa = aggregatInfo.getDkHa();
            this.flaecheGesamt = afHa.add(dglHa).add(dkHa);

            // Persönliche Daten
            this.betriebsname = aggregatInfo.getBetriebsname();
            this.anschrift = aggregatInfo.getAnschrift();

            // Flags
            this.wirtschaftsform = aggregatInfo.isOekologisch();
            this.junglandwirt = aggregatInfo.isJunglandwirt();
            this.gibtKuhmilchAb = aggregatInfo.isGibtKuhmilchAb();

            // GA DATA DIREKT
            Map<EBasisraemieTiere, BigDecimal> td = aggregatInfo.getTierData();
            this.tierData.clear();
            this.tierData.putAll(td);

            // GA GES
            Map<String, BigDecimal> gd = aggregatInfo.getGesData();
            this.gesData.clear();
            this.gesData.putAll(gd);

            this.basispraemieResult = basispraemieRechnung.calculate(
                    this.flaecheGesamt,
                    this.junglandwirt,
                    this.gibtKuhmilchAb,
                    this.gesData
            );
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    public String getCurrentYear() {
        return currentYear;
    }

    public String getDisclaimer() {
        return disclaimer;
    }

    public BigDecimal getAfHa() {
        return afHa;
    }

    public BigDecimal getDglHa() {
        return dglHa;
    }

    public BigDecimal getDkHa() {
        return dkHa;
    }

    public BigDecimal getFlaecheGesamt() {
        return flaecheGesamt;
    }

    public String getBetriebsname() {
        return betriebsname;
    }

    public String getAnschrift() {
        return anschrift;
    }

    public boolean getWirtschaftsform() {
        return wirtschaftsform;
    }

    public boolean isJunglandwirt() {
        return junglandwirt;
    }

    public Map<EBasisraemieTiere, BigDecimal> getTierData() {
       return tierData;
    }

    public boolean isGibtKuhmilchAb() {
        return gibtKuhmilchAb;
    }

    public Map<String, BigDecimal> getGesData() {
        return gesData;
    }

    public BasispraemieResult getDirectPaymentsResult() {
        return basispraemieResult;
    }

    public String getDisplayNameMuttis(String key) {
        switch (key) {
            case "BEANTRAGTETIERE": return "Mutterkühe";
            case "BEANTRAGTESZTIERE": return "Mutterschafe/Mutterziegen";
            default: return key;
        }
    }

    public String getDisplayNameTiere(String key) {
        switch (key) {
            case "RINDER_UEBER_2_JAHRE_INPUT": return "Rinder über 2 Jahre";
            case "RINDER_6_MONATE_2_JAHRE_INPUT": return "Rinder 6 Monate - 2 Jahre";
            case "RINDER_UNTER_6_MONATE_INPUT": return "Rinder unter 6 Monate";
            case "EQUIDEN_UEBER_6_MONATE_INPUT": return "Equiden über 2 Jahre";
            case "SCHAFE_INPUT": return "Schafe";
            case "ZIEGEN_INPUT": return "Ziegen";
            case "DAMWILD_INPUT": return "Damwild";
            case "ROTWILD_INPUT": return "Rotwild";
            default: return key;
        }
    }

    public String getDisplayNameOeko(String key) {
        if (key.equals("true")) {
            return "Ökologisch";
        }
        return "Konventionell";
    }
    public String getDisplayNameJlw(String key) {
        if (key.equals("true")) {
            return "Ja";
        }
        return "Nein";
    }

    public String getDisplayNameMilch(String key) {
        if (key.equals("true")) {
            return "Ja";
        }
        return "Nein";
    }

    public boolean isAcknowledged() {
        return acknowledged;
    }

    public boolean isCheckboxAgreed() {
        return checkboxAgreed;
    }

    public void setCheckboxAgreed(boolean checkboxAgreed) {
        this.checkboxAgreed = checkboxAgreed;
    }

    public void confirmDisclaimer() {
        if (checkboxAgreed) {
            acknowledged = true;
        } else {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Bitte bestätigen Sie mit einem Haken, dass Sie den Hinweis gelesen haben", null));
        }
    }

    // Temporär

    public String getCustomValue1() {
        return customValue1;
    }

    public String getCustomValue2() {
        return customValue2;
    }

    public void berechnen(){};
}
