package de.ibykus.oasx.controller.basispraemie.dto;

import de.ibykus.oasx.controller.basispraemie.BasispraemieRepository.EBasisraemieTiere;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.Map;

public class BasispraemieAggregatInfo implements Serializable {

    private static long serialVersionUID = 1L;

    // Fläche
    private final BigDecimal afHa;
    private final BigDecimal dglHa;
    private final BigDecimal dkHa;

    // Persönliche Daten
    private final String betriebsname;
    private final String anschrift;

    // Flags
    private final boolean oekologisch;
    private final boolean junglandwirt;
    private final boolean gibtKuhmilchAb;

    // Tiere-Data
    private final EnumMap<EBasisraemieTiere, BigDecimal> tierData;

    // GES-Data
    private final Map<String, BigDecimal> gesData;

    public BasispraemieAggregatInfo(
            BigDecimal afHa,
            BigDecimal dglHa,
            BigDecimal dkHa,
            String betriebsname,
            String anschrift,
            boolean oekologisch,
            boolean junglandwirt,
            boolean gibtKuhmilchAb,
            EnumMap<EBasisraemieTiere, BigDecimal> tierData,
            Map<String, BigDecimal> gesData) {
        this.afHa = afHa;
        this.dglHa = dglHa;
        this.dkHa = dkHa;
        this.betriebsname = betriebsname;
        this.anschrift = anschrift;
        this.oekologisch = oekologisch;
        this.junglandwirt = junglandwirt;
        this.gibtKuhmilchAb = gibtKuhmilchAb;
        this.tierData = tierData;
        this.gesData = gesData;
    }

    public BigDecimal getAfHa() {
        return afHa;
    }

    public BigDecimal getDglHa() {
        return dglHa;
    }

    public BigDecimal getDkHa() {
        return dkHa;
    }

    public String getBetriebsname() {
        return betriebsname;
    }

    public String getAnschrift() {
        return anschrift;
    }

    public boolean isOekologisch() {
        return oekologisch;
    }

    public boolean isJunglandwirt() {
        return junglandwirt;
    }

    public boolean isGibtKuhmilchAb() {
        return gibtKuhmilchAb;
    }

    public EnumMap<EBasisraemieTiere, BigDecimal> getTierData() {
        return tierData;
    }

    public Map<String, BigDecimal> getGesData() {
        return gesData;
    }
}
