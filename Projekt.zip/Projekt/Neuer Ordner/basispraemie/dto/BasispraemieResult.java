package de.ibykus.oasx.controller.basispraemie.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BasispraemieResult implements Serializable {

    private static final long serialVersionUID = 1L;

    // Rates
    private final BigDecimal basisPraemieRateEurHa;
    private final BigDecimal umvFirst40RateEurHa;
    private final BigDecimal umvNext20RateEurHa;
    private final BigDecimal junglandwirtRateEurHa;
    private final BigDecimal mutterkuhRateEurTier;
    private final BigDecimal schafZiegeRateEurTier;

    // Summe
    private final BigDecimal basispraemieGesamtEur;
    private final BigDecimal umverteilungsPraemieEur;
    private final BigDecimal junglandwirtePraemieEur;
    private final BigDecimal mutterkuhPraemieEur;
    private final BigDecimal schafZiegePraemieEur;

    // Ergebnis
    private final BigDecimal summeBasispraemieEur;

    public BasispraemieResult(
            BigDecimal basisPraemieRateEurHa,
            BigDecimal umvFirst40RateEurHa,
            BigDecimal umvNext20RateEurHa,
            BigDecimal junglandwirtRateEurHa,
            BigDecimal mutterkuhRateEurTier,
            BigDecimal schafZiegeRateEurTier,
            BigDecimal basispraemieGesamtEur,
            BigDecimal umverteilungsPraemieEur,
            BigDecimal junglandwirtePraemieEur,
            BigDecimal mutterkuhPraemieEur,
            BigDecimal schafZiegePraemieEur,
            BigDecimal summeBasispraemieEur) {
        this.basisPraemieRateEurHa = basisPraemieRateEurHa;
        this.umvFirst40RateEurHa = umvFirst40RateEurHa;
        this.umvNext20RateEurHa = umvNext20RateEurHa;
        this.junglandwirtRateEurHa = junglandwirtRateEurHa;
        this.mutterkuhRateEurTier = mutterkuhRateEurTier;
        this.schafZiegeRateEurTier = schafZiegeRateEurTier;
        this.basispraemieGesamtEur = basispraemieGesamtEur;
        this.umverteilungsPraemieEur = umverteilungsPraemieEur;
        this.junglandwirtePraemieEur = junglandwirtePraemieEur;
        this.mutterkuhPraemieEur = mutterkuhPraemieEur;
        this.schafZiegePraemieEur = schafZiegePraemieEur;
        this.summeBasispraemieEur = summeBasispraemieEur;
    }

    public BigDecimal getBasisPraemieRateEurHa() {
        return basisPraemieRateEurHa;
    }

    public BigDecimal getUmvFirst40RateEurHa() {
        return umvFirst40RateEurHa;
    }

    public BigDecimal getUmvNext20RateEurHa() {
        return umvNext20RateEurHa;
    }

    public BigDecimal getJunglandwirtRateEurHa() {
        return junglandwirtRateEurHa;
    }

    public BigDecimal getMutterkuhRateEurTier() {
        return mutterkuhRateEurTier;
    }

    public BigDecimal getSchafZiegeRateEurTier() {
        return schafZiegeRateEurTier;
    }

    public BigDecimal getBasispraemieGesamtEur() {
        return basispraemieGesamtEur;
    }

    public BigDecimal getUmverteilungsPraemieEur() {
        return umverteilungsPraemieEur;
    }

    public BigDecimal getJunglandwirtePraemieEur() {
        return junglandwirtePraemieEur;
    }

    public BigDecimal getMutterkuhPraemieEur() {
        return mutterkuhPraemieEur;
    }

    public BigDecimal getSchafZiegePraemieEur() {
        return schafZiegePraemieEur;
    }

    public BigDecimal getSummeBasispraemieEur() {
        return summeBasispraemieEur;
    }

    public List<Row> asTableRows() {
        List<Row> rows = new ArrayList<>();
        rows.add(new Row("Basisprämie [€/ha]", basisPraemieRateEurHa, basispraemieGesamtEur));
        rows.add(new Row("Umverteilungsprämie [€/ha]",
                "1-40 ha: " + umvFirst40RateEurHa + " €, 41-60 ha: " + umvNext20RateEurHa + " €", umverteilungsPraemieEur));
        rows.add(new Row("Junglandwirteprämie [€/ha] (max. 120 ha LF)", junglandwirtRateEurHa, junglandwirtePraemieEur));
        rows.add(new Row("Tierprämien: Mutterkühe [€/Tier] (min. 3 Tiere und keine Milchabgabe)", mutterkuhRateEurTier, mutterkuhPraemieEur));
        rows.add(new Row("Tierprämien: Mutterschafe/ Mutterziegen [€/Tier] (min. 6 Tiere)", schafZiegeRateEurTier, schafZiegePraemieEur));
        rows.add(new Row("Summe", "", summeBasispraemieEur));

        return rows;
    }

    public static class Row {
        private final String label;
        private final Object rate;
        private final BigDecimal amount;

        public Row(String label, Object rate, BigDecimal amount) {
            this.label = label;
            this.rate = rate;
            this.amount = amount;
        }

        public String getLabel() {
            return label;
        }

        public Object getRate() {
            return rate;
        }

        public BigDecimal getAmount() {
            return amount;
        }
    }
}
