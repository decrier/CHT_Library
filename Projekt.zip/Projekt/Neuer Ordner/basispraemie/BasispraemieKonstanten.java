package de.ibykus.oasx.controller.basispraemie;

import java.math.BigDecimal;

public class BasispraemieKonstanten {
    public static final BigDecimal BASIS_EUR_HA = new BigDecimal("152");
    public static final BigDecimal UMV_1_40_EUR_HA = new BigDecimal("68");
    public static final BigDecimal UMV_41_60_EUR_HA = new BigDecimal("40");
    public static final BigDecimal JLW_EUR_HA = new BigDecimal("134");
    public static final BigDecimal MUTTERKUH_EUR_TIER = new BigDecimal("87");
    public static final BigDecimal SZ_EUR_TIER = new BigDecimal("39");
    public static final BigDecimal HA_40 = new BigDecimal("40");
    public static final BigDecimal HA_60 = new BigDecimal("60");
    public static final BigDecimal HA_120 = new BigDecimal("120");
    public static final int EUR_SCALE = 2;
}
