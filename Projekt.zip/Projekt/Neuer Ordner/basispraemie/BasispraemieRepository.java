package de.ibykus.oasx.controller.basispraemie;

import de.ibykus.oasx.controller.basispraemie.dto.BasispraemieAggregatInfo;
import de.ibykus.oasx.controller.common.logger.OasLogger;
import de.ibykus.oasx.controller.common.logger.OasLoggerFactory;
import de.ibykus.oasx.controller.database.DBConnection;
import de.ibykus.oasx.controller.database.UniversalDBController;
import de.ibykus.oasx.controller.enums.EQuerryTypes;
import de.ibykus.oasx.controller.enums.ESQLQueries;
import de.ibykus.oasx.cupcake.template.utils.FragTim;
import de.ibykus.oasx.model.CodelisteAEntry;
import de.ibykus.oasx.model.Pair;
import de.ibykus.oasx.model.exception.OasException;
import de.ibykus.oasx.view.enums.EFormType;
import org.json.JSONException;
import org.json.JSONObject;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Named
@ApplicationScoped
public class BasispraemieRepository {

    private UniversalDBController universalDBController = new UniversalDBController();
    private final OasLogger logger = OasLoggerFactory.getLogger(this.getClass());
    private final String currentYear = String.valueOf(FragTim.getCurrentYear());

    // Ackerfläche gesamt
    public BigDecimal getAF(String pi) throws Exception {
        return query(pi, "AL");
    }

    // Grünlandfläche
    public BigDecimal getDGL(String pi) throws Exception {
        return query(pi, "DGL");
    }

    // Dauerkulturen
    public BigDecimal getDK(String pi) throws Exception {
        return query(pi, "DK");
    }

    /**
     * Summiert alle Schläge entsprechender Kategorie (AF für "Ackerfläche,
     * DGL für Grünlandfläche, DK für Dauerkulturen)
     *
     * @param pi current pi
     * @param groupFK Kategorie
     * @return die Summe aller Schläge je nach Kategorie
     */
    private BigDecimal query(String pi, String groupFK) throws OasException {
        List<JSONObject> schlaege = universalDBController.pull(ESQLQueries.FIG_SCHLAEGE, pi);
        Map<Integer, String> codeliste_a = universalDBController.pull(ESQLQueries.CODELISTE_A).stream()
                                            .map(CodelisteAEntry::new)
                                            .collect(Collectors.toMap(
                                                    CodelisteAEntry::getKla_art,
                                                    CodelisteAEntry::getKla_fk,
                                                    (first, duplicate) -> first));

        BigDecimal flaechenSumme = schlaege.stream()
                .filter((schlag) -> schlag.has("NCODE_AKTUELL") && schlag.getString("NCODE_AKTUELL").matches("^[0-9]+$"))
                .filter((schlag) -> Objects.equals(codeliste_a.get(schlag.getInt("NCODE_AKTUELL")), groupFK))
                .map(s -> BigDecimal.valueOf(s.optDouble("BEANTR_GROESSE_AKTUELL", 0.0)))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return flaechenSumme.setScale(3, RoundingMode.HALF_UP);
    }

    public enum EBasisraemiePersonData {
        BETRIEBSNAME,
        ANSCHRIFT,
        ;
    }

    /**
     * Aggregiert die persönliche Informationen
     *
     * @param pi current pi
     * @return die EnumMap mit dem Name und Anschrifft des Betriebs/Eigentümers
     */
    public EnumMap<EBasisraemiePersonData, String> getPersonInfoById(String pi) {

        EnumMap<EBasisraemiePersonData, String> personInfo = new EnumMap<>(EBasisraemiePersonData.class);
        String betriebsname = "";
        String anschrift = "";

        for (EBasisraemiePersonData pd : EBasisraemiePersonData.values()) {
            personInfo.put(pd, "keine Daten");
        }
        try {
            List<JSONObject> personDataList = universalDBController.pull(ESQLQueries.PERSOENLICHE_DATEN, pi);
            if (personDataList == null || personDataList.isEmpty()) {
                return personInfo;
            }
            JSONObject personData = personDataList.get(0).getJSONObject("CONTENT");
            if (personData == null) {
                return personInfo;
            }

            String persart = personData.optString("PERSART", "");
            String anrede = personData.optString("ANREDE", "");
            String vorname = personData.optString("VORNAME", "");
            String name = personData.optString("NAME1", "");
            String strasse = personData.optString("STRASSE", "");
            String plz = personData.optString("PLZ", "");
            String ort = personData.optString("ORT", "");

            if (persart != null && persart.toLowerCase().equals("natürlich")) {
                betriebsname = String.join(" ", anrede, vorname, name);
            }
            if (persart != null && persart.toLowerCase().equals("juristisch")) {
                betriebsname = name;
            }

            anschrift = String.join(", ", strasse, plz, ort);

            if (betriebsname != null && !betriebsname.isEmpty()) {
                personInfo.put(EBasisraemiePersonData.BETRIEBSNAME, betriebsname);
            }
            if (anschrift != null && !anschrift.isEmpty()) {
                personInfo.put(EBasisraemiePersonData.ANSCHRIFT, anschrift);
            }

        } catch (OasException e) {
            logger.error(e.getMessage(), e);
        } catch (IndexOutOfBoundsException e) {
            logger.error(e.getMessage(), e);
        }
        return personInfo;
    }

    public enum EBasisraemieTiere {
        RINDER_UEBER_2_JAHRE_INPUT,
        RINDER_6_MONATE_2_JAHRE_INPUT,
        RINDER_UNTER_6_MONATE_INPUT,
        EQUIDEN_UEBER_6_MONATE_INPUT,
        SCHAFE_INPUT,
        ZIEGEN_INPUT,
        DAMWILD_INPUT,
        ROTWILD_INPUT,
        ;
    }

//    private final String SQL_DIREKT_GES =
//            "SELECT b.eformtype, b.content " +
//            "FROM oasx.ga_bewilligung_" + currentYear + " b " +
//            "JOIN oasx.ga_massnahme_" + currentYear + " m " +
//            "ON b.massnahme_uuid = m.uuid " +
//            "WHERE m.pi = ? AND b.eformtype in (?,?)";

//    private Map<String, JSONObject> loadGaJsons(String pi) {
//        Map<String, JSONObject> map = new HashMap<>();
//        try (Connection connection = hikariDataSource.getConnection();
//             PreparedStatement ps = connection.prepareStatement(SQL_DIREKT_GES)){
//            ps.setString(1, pi);
//            ps.setString(2, "GEMEINSAMER_ANTRAG_DATA_DIREKT");
//            ps.setString(3, "GEMEINSAMER_ANTRAG_GES");
//            try (ResultSet rs = ps.executeQuery()){
//                while (rs.next()) {
//                    String type = rs.getString("eformtype");
//                    String content = rs.getString("content");
//                    if (content != null) {
//                        try {
//                            map.put(type, new JSONObject(content));
//                        } catch (JSONException e) {
//                            logger.error(e.getMessage());
//                        }
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            logger.error(e.getMessage());
//        }
//        return map;
//    }

    /**
     * Liest die Informationen aus der entsprechenden EFormType der "ga_bewilligung_2025" Tabelle
     *
     * @return JSON-Objekt aus der Spalte "content"
     */
    private JSONObject loadGaJsons(String pi, String eformType) throws OasException {
        String SQL_GA = "SELECT b.eformtype, b.content " +
                        "FROM oasx.ga_bewilligung_" + currentYear + " b " +
                        "JOIN oasx.ga_massnahme_" + currentYear + " m " +
                        "ON b.massnahme_uuid = m.uuid " +
                        "WHERE m.pi = ? AND b.eformtype = ?";
        JSONObject gaJson = new JSONObject();
        List<Object> values = new ArrayList<>();
        values.add(pi);
        values.add(eformType);
        List<EQuerryTypes> types = new ArrayList<>(Arrays.asList(EQuerryTypes.STRING, EQuerryTypes.STRING));
        List<JSONObject> gaJsons = universalDBController.pull(SQL_GA, values, types);
        if (gaJsons == null || gaJsons.isEmpty()) {
            return new JSONObject();
        }
        try {
            gaJson = gaJsons.get(0).getJSONObject("CONTENT");
        } catch (JSONException e) {
            logger.error(e.getMessage());
        }
        return gaJson;
    }

    /**
     * Aggregiert alle Daten in einem Objekt zur weiteren Übertragung
     * an die Klasse für Berechnungen
     *
     * @return BasispraemieAggregatInfo Objekt mit sämtlichen Informationen
     */
    public BasispraemieAggregatInfo loadAllForPi(String pi) throws Exception {

        // 1. Flächen
        BigDecimal af = getAF(pi);
        BigDecimal dgl = getDGL(pi);
        BigDecimal dk = getDK(pi);

        // 2. JSONS
//        Map<String, JSONObject> jsons = loadGaJsons(pi);
//        JSONObject direktData = jsons.getOrDefault("GEMEINSAMER_ANTRAG_DATA_DIREKT", new JSONObject());
//        JSONObject gesData = jsons.getOrDefault("GEMEINSAMER_ANTRAG_GES", new JSONObject());
        JSONObject direktData = loadGaJsons(pi, "GEMEINSAMER_ANTRAG_DATA_DIREKT");
        JSONObject gesData = loadGaJsons(pi, "GEMEINSAMER_ANTRAG_GES");

        // 3. Flags
        boolean oeko = "on".equalsIgnoreCase(direktData.optString("OEKOPRODUKTION", ""));
        boolean jlw = "on".equalsIgnoreCase(direktData.optString("JLPALLGEMEIN", ""));
        boolean milch = "on".equalsIgnoreCase(gesData.optString("MUKUEHERKLEARUNG1", ""));

        // 4. Tiere
        EnumMap<EBasisraemieTiere, BigDecimal> tiere = new EnumMap<>(EBasisraemieTiere.class);
        for (EBasisraemieTiere t: EBasisraemieTiere.values()) {
            String value = "";
            if (direktData.has(t.name()) && !direktData.isNull(t.name())) {
                value = direktData.getString(t.name());
            }
            tiere.put(t, parseToDecimal(value));
        }

        // 5.Muttis
        Map<String, BigDecimal> gesTiere = new HashMap<>();
        List<String> values = new ArrayList<>(Arrays.asList("BEANTRAGTETIERE", "BEANTRAGTESZTIERE"));
        for (String s: values) {
            String value = "";
            if (gesData.has(s) && !gesData.isNull(s)) {
                value = gesData.getString(s);
            }
            gesTiere.put(s, parseToDecimal(value));
        }

        // 6. Persönliche Daten
        EnumMap<EBasisraemiePersonData, String> personInfo = getPersonInfoById(pi);

        return new BasispraemieAggregatInfo(
                getValueNotNull(af), getValueNotNull(dgl), getValueNotNull(dk),
                personInfo.get(EBasisraemiePersonData.BETRIEBSNAME), personInfo.get(EBasisraemiePersonData.ANSCHRIFT),
                oeko, jlw, milch,
                tiere, gesTiere
        );
    }


    /**
     * Konvertiert String in BigDecimal, berücksichtigt alle Variationen
     *
     * @param v übergebene String
     * @return Decimalwert der Zeichenfolge
     */
    private static BigDecimal parseToDecimal(Object v) {
        if (v == null || JSONObject.NULL.equals(v)) {
            return BigDecimal.ZERO;
        }
        if (v instanceof BigDecimal) {
            return (BigDecimal) v;
        }
        if (v instanceof Number) {
            return new BigDecimal(v.toString());
        }
        String s = String.valueOf(v).trim();
        if (s.isEmpty() || "null".equalsIgnoreCase(s)) {
            return BigDecimal.ZERO;
        }
        if (!s.matches("[-+0-9.,\\s]+")) {
            return BigDecimal.ZERO;
        }
        if (s.contains(",") && !s.contains(".")) {
            s = s.replace(",", ".");
        } else if (s.contains(",") && s.contains(".")) {
            s = s.replace(".", "");
            s = s.replace(",", ".");
        }
        try {
            return new BigDecimal(s);
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * um NullPointerException in weiteren Berechnungen zu vermeiden.
     *
     * @return der Wert von v, wenn er nicht null ist, andernfalls die Konstante BigDecimal.ZERO
     */
    private static BigDecimal getValueNotNull(BigDecimal v) {
        return (v != null) ? v : BigDecimal.ZERO;
    }
}
