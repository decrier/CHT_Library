package de.ibykus.oasx.controller.basispraemie;

import de.ibykus.oasx.controller.basispraemie.dto.BasispraemieResult;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

@Named
@ApplicationScoped
public class BasispraemieRechnung {

    public BasispraemieResult calculate(
            BigDecimal flaecheGesamt,
            boolean isJunglandwirt,
            boolean gibtKuhMilchAb,
            Map<String, BigDecimal> gesData) {

//        BigDecimal flaecheGesamt = af.add(dgl).add(dk);
//        BigDecimal flaecheGesamt = getValueNotNull(basisRes.getTotalAreaHa());

        BigDecimal basisBetrag = getValueNotNull(flaecheGesamt
                .multiply(BasispraemieKonstanten.BASIS_EUR_HA)
                .setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP));
        BigDecimal umv = calcUmverteilungsPraemie(flaecheGesamt);
        BigDecimal jlw = calcJunglandwirtePraemie(flaecheGesamt, isJunglandwirt);
        BigDecimal mutterkueheAnzahl = getValueNotNull(gesData != null ? gesData.get("BEANTRAGTETIERE") : null);
        BigDecimal szAnz = getValueNotNull(gesData != null ? gesData.get("BEANTRAGTESZTIERE") : null);
        BigDecimal mutterkuhPraemie = calcMutterkuhPraemie(mutterkueheAnzahl, gibtKuhMilchAb);
        BigDecimal schafZiegePraemie = calcSchafZiegePraemie(szAnz);

        BigDecimal summe = basisBetrag.add(umv).add(jlw).add(mutterkuhPraemie).add(schafZiegePraemie)
                .setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);

        return new BasispraemieResult(
                BasispraemieKonstanten.BASIS_EUR_HA,
                BasispraemieKonstanten.UMV_1_40_EUR_HA,
                BasispraemieKonstanten.UMV_41_60_EUR_HA,
                BasispraemieKonstanten.JLW_EUR_HA,
                BasispraemieKonstanten.MUTTERKUH_EUR_TIER,
                BasispraemieKonstanten.SZ_EUR_TIER,
                basisBetrag, umv, jlw, mutterkuhPraemie, schafZiegePraemie, summe
        );
    }

    private static BigDecimal calcUmverteilungsPraemie(BigDecimal flaecheGesamt) {
        if (flaecheGesamt.signum() <= 0) {
            return BigDecimal.ZERO.setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
        }
        BigDecimal teil1 = min(flaecheGesamt, BasispraemieKonstanten.HA_40).multiply(BasispraemieKonstanten.UMV_1_40_EUR_HA);
        BigDecimal rest1 = max(flaecheGesamt.subtract(BasispraemieKonstanten.HA_40), BigDecimal.ZERO);
        BigDecimal teil2 = min(rest1, new BigDecimal("20")).multiply(BasispraemieKonstanten.UMV_41_60_EUR_HA);
        return teil1.add(teil2).setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal calcJunglandwirtePraemie(BigDecimal flaecheGesamt, boolean isJunglandwirt) {
        if (!isJunglandwirt || flaecheGesamt.signum() <= 0) {
            return BigDecimal.ZERO.setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
        }
        BigDecimal getFoerdert = min(flaecheGesamt, BasispraemieKonstanten.HA_120);
        return getFoerdert.multiply(BasispraemieKonstanten.JLW_EUR_HA).setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal calcMutterkuhPraemie(BigDecimal anzahl, boolean gibtKuhmilchAb) {
        if (anzahl.compareTo(new BigDecimal("3")) >= 0 && !gibtKuhmilchAb) {
            return anzahl.multiply(BasispraemieKonstanten.MUTTERKUH_EUR_TIER).setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO.setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal calcSchafZiegePraemie(BigDecimal anzahl) {
        if (anzahl.compareTo(new BigDecimal("6")) >= 0) {
            return anzahl.multiply(BasispraemieKonstanten.SZ_EUR_TIER).setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO.setScale(BasispraemieKonstanten.EUR_SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal getValueNotNull(BigDecimal v) {
        return (v != null) ? v : BigDecimal.ZERO;
    }

    private static BigDecimal min(BigDecimal a, BigDecimal b) {
        return (a.compareTo(b) <= 0) ? a : b;
    }

    private static BigDecimal max(BigDecimal a, BigDecimal b) {
        return (a.compareTo(b) >= 0) ? a : b;
    }
}
